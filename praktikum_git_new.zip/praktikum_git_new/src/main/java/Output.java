import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "groups", "pairs", "successorPairs", "successorParticipants" })
public class Output {
    @JsonProperty("groups")
    public List<Group> groups = null;
    @JsonProperty("pairs")
    public List<Pair> pairs = null;
    @JsonProperty("successorPairs")
    public List<Pair> successorPairs = null;
    @JsonProperty("successorParticipants")
    public List<Participant> successorParticipants = null;

    public Output(List<Group> groups, List<Pair> pairs, List<Pair> successorPairs, List<Participant> successorParticipants) {
        this.groups = groups;
        this.pairs = pairs;
        this.successorPairs = successorPairs;
        this.successorParticipants = successorParticipants;
    }

    @Override
    public String toString() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);

        try {
            // Convert the Pair object to a JSON string
            return mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            // If there is an error in the conversion process, return a simple string representation
            return super.toString();
        }
    }
}
