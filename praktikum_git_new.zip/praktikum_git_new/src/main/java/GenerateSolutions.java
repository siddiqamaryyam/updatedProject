public class GenerateSolutions {
}

