import enums.Course;

import java.io.*;
import java.util.*;
import java.util.stream.Stream;

public class Main {
    private final List<Participant> initialParticipants;
    private final List<Pair> initialPairs;

    public static void main(String[] args) throws IOException {
       Main main = new Main();
    }

    public Main() throws IOException {
        CSVReader reader = new CSVReader("./src/main/resources/teilnehmerliste.csv");
        initialParticipants = reader.initialParticipants;
        initialPairs = reader.initialPairs;

        int foodWeight = 1;
        int genderWeight = 10;
        int ageWeight = 5;

        PairController pairController = new PairController(initialParticipants, foodWeight, genderWeight, ageWeight);

        List<Pair> resultingPairs = new ArrayList<>(Stream.concat(initialPairs.stream(), pairController.finalPairs.stream()).toList());

        Location partyLocation = Location.readFromCsv();
        assert partyLocation != null;

        GroupController groupController = new GroupController(resultingPairs, partyLocation, foodWeight, genderWeight, ageWeight);

        // First group list is the best
        List<Group> groupList = groupController.finalGroups;
        System.out.println(getAverageAgeDiff(groupList));
        System.out.println(getAverageGenderDiff(groupList));
        System.out.println(getPreferenceDeviation(groupList));
        System.out.println(GroupController.calculatePathLength(groupList, partyLocation));

        BufferedWriter writer = new BufferedWriter(new FileWriter("./output_c.json"));
        writer.write(new Output(groupList, resultingPairs, groupController.successorPairs, pairController.successorParticipants).toString());
        writer.close();
    }



    public static final double R = 6371; // Radius of the earth in km

    public static double haversine(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        lat1 = Math.toRadians(lat1);
        lat2 = Math.toRadians(lat2);

        double a = Math.pow(Math.sin(dLat/2),2) + Math.pow(Math.sin(dLon/2),2) * Math.cos(lat1) * Math.cos(lat2);
        double c = 2 * Math.asin(Math.sqrt(a));
        return R * c;
    }

    public static void sortPairsByDistance(List<Pair> pairs, double centralLat, double centralLon) {
        pairs.sort((p1, p2) -> {
            double dist1 = haversine(centralLat, centralLon, p1.getKitchen().latitude, p1.getKitchen().longitude);
            double dist2 = haversine(centralLat, centralLon, p2.getKitchen().latitude, p2.getKitchen().longitude);
            return Double.compare(dist2, dist1); // For descending order
        });
    }

    public static double getAverageAgeDiff(List<Group> groups) {
        return groups.stream().mapToDouble(Group::getGroupAgeDiff).average().getAsDouble();
    }

    public static double getAverageGenderDiff(List<Group> groups) {
        return groups.stream().mapToDouble(Group::getGroupGenderDiff).average().getAsDouble();
    }

    public static double getPreferenceDeviation(List<Group> groups) {
        return Group.getAllPairs(groups).stream().mapToDouble(Pair::getPreferenceDeviation).average().getAsDouble();
    }
}
