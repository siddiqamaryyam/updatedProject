import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "emergencyKitchen", "story", "longitude", "latitude" })
public class Kitchen {
    @JsonProperty("emergencyKitchen")
    public Boolean emergencyKitchen;
    @JsonProperty("story")
    public Integer story;
    @JsonProperty("longitude")
    public Double longitude;
    @JsonProperty("latitude")
    public Double latitude;

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Kitchen(Boolean emergencyKitchen, Integer story, Double longitude, Double latitude) {
        this.emergencyKitchen = emergencyKitchen;
        this.story = story;
        this.longitude = longitude;
        this.latitude = latitude;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Kitchen kitchen = (Kitchen) o;
        return Double.compare(kitchen.longitude, longitude) == 0 &&
                Double.compare(kitchen.latitude, latitude) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(longitude, latitude);
    }

    @Override
    public String toString() {
        ObjectMapper mapper = new ObjectMapper();

        try {
            // Convert the Pair object to a JSON string
            return mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            // If there is an error in the conversion process, return a simple string representation
            return super.toString();
        }
    }

    public Boolean getEmergencyKitchen() {
        return emergencyKitchen;
    }

    // Getters and setters...
}
