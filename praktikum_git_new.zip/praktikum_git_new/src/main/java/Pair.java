import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import enums.FoodPreference;
import enums.Gender;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonPropertyOrder({ "premade", "foodPreference", "firstParticipant", "secondParticipant" })
public class Pair {
    @JsonProperty("premade")
    public Boolean premade;

    public FoodPreference getFoodPreference() {
        return foodPreference;
    }

    public Kitchen getKitchen() {
        return firstParticipant.getKitchen();
    }

    @JsonProperty("foodPreference")
    public FoodPreference foodPreference;
    @JsonProperty("firstParticipant")
    public Participant firstParticipant;
    @JsonProperty("secondParticipant")
    public Participant secondParticipant;

    // Test ob FoodPreference richtig gesetzt wird:
    //Participant par1 = new Participant("i", "test", FoodPreference.VEGAN, )....
    //Participant par2 = new Participant("i", "test", FoodPreference.VEGAN, )....
    //Pair testPair = new Pair(true, par1, par2)
    // Assertation.assertEquals(FoodPreference.VEGAN, testPair.getFoodPreference())

    public Pair(Boolean premade, Participant firstParticipant, Participant secondParticipant) {
        this.premade = premade;
        this.firstParticipant = firstParticipant;
        this.secondParticipant = secondParticipant;

        // Rule 1: If both participants have the same preference, that's the main preference.
        if(firstParticipant.foodPreference == secondParticipant.foodPreference) {
            this.foodPreference = firstParticipant.foodPreference;
        }
        // Rule 2: If one participant is a meat lover and the other is "Egali", the main preference is "Fleischi".
        else if((firstParticipant.foodPreference == FoodPreference.MEAT && secondParticipant.foodPreference == FoodPreference.NONE)
                || (secondParticipant.foodPreference == FoodPreference.MEAT && firstParticipant.foodPreference == FoodPreference.NONE)) {
            this.foodPreference = FoodPreference.MEAT;
        }
        // Rule 3: If a "Fleischi"/"Egali" is paired with a vegetarian/vegan, the "Fleischi"/"Egali" is inferior.
        else if((firstParticipant.foodPreference == FoodPreference.MEAT && (secondParticipant.foodPreference == FoodPreference.VEGGIE || secondParticipant.foodPreference == FoodPreference.VEGAN))
                || (secondParticipant.foodPreference == FoodPreference.MEAT && (firstParticipant.foodPreference == FoodPreference.VEGGIE || firstParticipant.foodPreference == FoodPreference.VEGAN))) {
            this.foodPreference = (firstParticipant.foodPreference == FoodPreference.VEGGIE || secondParticipant.foodPreference == FoodPreference.VEGGIE) ? FoodPreference.VEGGIE : FoodPreference.VEGAN;
        }
        else if((firstParticipant.foodPreference == FoodPreference.NONE && (secondParticipant.foodPreference == FoodPreference.VEGGIE || secondParticipant.foodPreference == FoodPreference.VEGAN))
                || (secondParticipant.foodPreference == FoodPreference.NONE && (firstParticipant.foodPreference == FoodPreference.VEGGIE || firstParticipant.foodPreference == FoodPreference.VEGAN))) {
            this.foodPreference = (firstParticipant.foodPreference == FoodPreference.VEGGIE || secondParticipant.foodPreference == FoodPreference.VEGGIE) ? FoodPreference.VEGGIE : FoodPreference.VEGAN;
        }
        // Rule 4: If one participant is a vegan and the other is a vegetarian, the main preference is "Vegan".
        else if((firstParticipant.foodPreference == FoodPreference.VEGAN && secondParticipant.foodPreference == FoodPreference.VEGGIE)
                || (secondParticipant.foodPreference == FoodPreference.VEGAN && firstParticipant.foodPreference == FoodPreference.VEGGIE)) {
            this.foodPreference = FoodPreference.VEGAN;
        }
        // If none of the above rules apply, default to NONE.
        else {
            this.foodPreference = FoodPreference.NONE;
        }
    }

    public Participant getFirstParticipant() {
        return firstParticipant;
    }

    public Participant getSecondParticipant() {
        return secondParticipant;
    }

    @Override
    public String toString() {
        ObjectMapper mapper = new ObjectMapper();

        try {
            // Convert the Pair object to a JSON string
            return mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            // If there is an error in the conversion process, return a simple string representation
            return super.toString();
        }
    }

    protected boolean isVeggie() {
        return foodPreference == FoodPreference.VEGGIE || foodPreference == FoodPreference.VEGAN;
    }

    public double calculateGenderDiff() {
        int count = 0;
        count += this.getFirstParticipant().getGender() == Gender.FEMALE ? 1 : 0;
        count += this.getSecondParticipant().getGender() == Gender.FEMALE ? 1 : 0;
        return Math.abs((double)count / 2.0 - 0.5);
    } // test

    public int getPreferenceDeviation() {
        int biggerPreference = Math.max(this.getFirstParticipant().getPreference(), this.getSecondParticipant().getPreference());
        int smallerPreference = Math.min(this.getFirstParticipant().getPreference(), this.getSecondParticipant().getPreference());
        return biggerPreference - smallerPreference;
    } // test

    private double genderScore() {
        if(firstParticipant.gender == secondParticipant.gender) {
            return 0.5;
        } else {
            return 0;
        }
    } //test

    public double calculateWeightedScore(int foodWeight, int genderWeight, int ageWeight) {
        double foodPreferenceDiff = this.firstParticipant.foodPreference.ordinal() - this.secondParticipant.foodPreference.ordinal();
        double genderDiff = this.genderScore();
        double ageRangeDiff = Math.abs(getSecondParticipant().ageRange() - this.getFirstParticipant().ageRange());

        return foodPreferenceDiff * foodWeight + genderDiff * genderWeight + ageRangeDiff * ageWeight;
    } //test

    // Get all groups of pair
    public List<Group> getAllGroups(List<Group> groups) {
        List<Group> allGroups = new ArrayList<>();
        for(Group group : groups) {
            if(group.getAllPairs().contains(this)) {
                allGroups.add(group);
            }
        }
        return allGroups;
    }
}

