import enums.Course;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class GroupController {
    List<Group> finalGroups;
    List<Pair> successorPairs = new ArrayList<>();

    public GroupController(List<Pair> resultingPairs, Location partyLocation, int foodWeight, int genderWeight, int ageWeight) {
        int bufferSize = 0;
        int multiplier = 9;

        List<List<Group>> randomList = new ArrayList<>();

        for (int i = 0; i < 1000; i++) {
            List<Group> groupList = new ArrayList<>();
            List<Pair> meatPairs = new ArrayList<>(resultingPairs.stream().filter(p -> !p.isVeggie()).toList());
            List<Pair> veganPairs = new ArrayList<>(resultingPairs.stream().filter(Pair::isVeggie).toList());

            Collections.shuffle(meatPairs);
            Collections.shuffle(veganPairs);

            int totalMeatSize = meatPairs.size();
            int mappedMeatSize = ((totalMeatSize - bufferSize) / multiplier) * multiplier;

            groupList.addAll(assembleGroups(meatPairs, partyLocation));

            int totalVeganSize = veganPairs.size();
            int mappedVeganSize = ((totalVeganSize - bufferSize) / multiplier) * multiplier;

            groupList.addAll(assembleGroups(veganPairs, partyLocation));

            randomList.add(groupList);
        }
        randomList.sort(
                Comparator.comparingDouble(gl -> gl.stream()
                        .mapToDouble((Group g) -> g.calculateWeightedScore(foodWeight, genderWeight, ageWeight))
                        .average()
                        .getAsDouble()
                )
        );

        this.finalGroups = randomList.get(0);
        List<Pair> allPairs = Group.getAllPairs(finalGroups);
        for (Pair p: resultingPairs) {
            if (!allPairs.contains(p)) {
                this.successorPairs.add(p);
            }
        }
    }

    private List<Group> assembleGroups(List<Pair> pairList, Location partyLocation) {
        List<Group> resultingGroups = new ArrayList<>();

        for (int i = 0; i < pairList.size()-9; i+=9) {
            List<Pair> tempPairs = new ArrayList<>(pairList.subList(i, i+9));

            Pair pair1 = tempPairs.get(0);
            Pair pair4 = tempPairs.get(3);
            Pair pair8 = tempPairs.get(7);
            Pair pair2 = tempPairs.get(1);
            Pair pair5 = tempPairs.get(4);
            Pair pair6 = tempPairs.get(5);
            Pair pair3 = tempPairs.get(2);
            Pair pair7 = tempPairs.get(6);
            Pair pair9 = tempPairs.get(8);

            Group group1 = new Group(Course.FIRST, pair1, pair2, pair3);
            Group group2 = new Group(Course.FIRST, pair4, pair5, pair6);
            Group group3 = new Group(Course.FIRST, pair8, pair7, pair9);
            Group group4 = new Group(Course.MAIN, pair2, pair4, pair8);
            Group group5 = new Group(Course.MAIN, pair5, pair3, pair7);
            Group group6 = new Group(Course.MAIN, pair6, pair1, pair9);
            Group group7 = new Group(Course.DESSERT, pair3, pair6, pair8);
            Group group8 = new Group(Course.DESSERT, pair7, pair1, pair4);
            Group group9 = new Group(Course.DESSERT, pair9, pair2, pair5);

            resultingGroups.add(group1);
            resultingGroups.add(group2);
            resultingGroups.add(group3);
            resultingGroups.add(group4);
            resultingGroups.add(group5);
            resultingGroups.add(group6);
            resultingGroups.add(group7);
            resultingGroups.add(group8);
            resultingGroups.add(group9);
        }

        return resultingGroups;
    }

    // Get all unique pairs of a list of groups.
    public static List<Pair> getAllPairs(List<Group> groups) {
        List<Pair> allPairs = new ArrayList<>();

        for (Group group : groups) {
            for (Pair pair : group.getAllPairs()) {
                if(!allPairs.contains(pair)) {
                    allPairs.add(pair);
                }
            }
        }

        return allPairs;
    }

    // Sort list of groups after first, second, third course
    public static void sortGroups(List<Group> groups) {
        groups.sort(Comparator.comparing(Group::getCourse));
    }

    public static double calculatePathLength(List<Group> groups, Location partyLocation) {
        List<Pair> allPairs = getAllPairs(groups);

        double pathLength = 0;

        for (Pair pair : allPairs) {
            List<Group> pairGroups = pair.getAllGroups(groups);
            sortGroups(pairGroups);
            pathLength += calculateGroupPathLength(pairGroups, partyLocation);
        }

        return pathLength;
    } //test (nur eine Gruppe in die groups liste hinzufügen und dann path length berechnen und vergleichen)

    public static double calculateGroupPathLength(List<Group> groups, Location partyLocation) {
        double groupPathLength = 0;

        for (int i = 0; i < groups.size(); i++) {
            if(i == groups.size() - 1) {
                groupPathLength += Main.haversine(groups.get(i).getCookingPair().getKitchen().getLatitude(), groups.get(i).getCookingPair().getKitchen().getLongitude(), partyLocation.getLatitude(), partyLocation.getLongitude());
            } else {
                groupPathLength += Main.haversine(groups.get(i).getCookingPair().getKitchen().getLatitude(), groups.get(i).getCookingPair().getKitchen().getLongitude(), groups.get(i+1).getCookingPair().getKitchen().getLatitude(), groups.get(i+1).getCookingPair().getKitchen().getLongitude());
            }
        }

        return groupPathLength;
    }

    // Get all groups of pair, sort by first, second, third course
    // calculate path







}
