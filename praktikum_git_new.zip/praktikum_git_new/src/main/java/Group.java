import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import enums.Course;
import enums.FoodPreference;
import enums.FoodType;
import enums.Gender;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE)
@JsonPropertyOrder({ "course", "foodType", "kitchen", "cookingPair", "secondPair", "thirdPair" })
public class Group {
    @JsonProperty("course")
    public Course course;
    @JsonProperty("foodType")
    public FoodType foodType;
    @JsonProperty("kitchen")
    public Kitchen kitchen;
    @JsonProperty("cookingPair")
    public Pair cookingPair;
    @JsonProperty("secondPair")
    public Pair secondPair;
    @JsonProperty("thirdPair")
    public Pair thirdPair;

    // Getters and setters...

    public Group(Course course, Pair cookingPair, Pair secondPair, Pair thirdPair) {
        this.kitchen = cookingPair.firstParticipant.kitchen;

        if(cookingPair.getFoodPreference() == FoodPreference.VEGAN
        || secondPair.getFoodPreference() == FoodPreference.VEGAN
        || thirdPair.getFoodPreference() == FoodPreference.VEGAN) {
            this.foodType = FoodType.VEGAN;
        } else if (cookingPair.getFoodPreference() == FoodPreference.VEGGIE
        || secondPair.getFoodPreference() == FoodPreference.VEGGIE
        || thirdPair.getFoodPreference() == FoodPreference.VEGGIE) {
            this.foodType = FoodType.VEGGIE;
        } else {
            this.foodType = FoodType.MEAT;
        }

        this.course = course;
        this.cookingPair = cookingPair;
        this.secondPair = secondPair;
        this.thirdPair = thirdPair;
    }

    public Pair getCookingPair() {
        return cookingPair;
    }

    public Pair getSecondPair() {
        return secondPair;
    }

    public Pair getThirdPair() {
        return thirdPair;
    }

    public Course getCourse() {
        return course;
    }

    public int getVeggieCount() {
        int count = 0;
        if(cookingPair.getFoodPreference() == FoodPreference.VEGGIE || cookingPair.getFoodPreference() == FoodPreference.VEGAN) {
            count++;
        }
        if(secondPair.getFoodPreference() == FoodPreference.VEGGIE || secondPair.getFoodPreference() == FoodPreference.VEGAN) {
            count++;
        }
        if(thirdPair.getFoodPreference() == FoodPreference.VEGGIE || thirdPair.getFoodPreference() == FoodPreference.VEGAN) {
            count++;
        }
        return count;
    }

    public int getMeatCount() {
        // TODO: maybe add meat count if
        int count = 0;
        if(cookingPair.getFoodPreference() == FoodPreference.MEAT || cookingPair.getFoodPreference() == FoodPreference.NONE) {
            count++;
        }
        if(secondPair.getFoodPreference() == FoodPreference.MEAT || secondPair.getFoodPreference() == FoodPreference.NONE) {
            count++;
        }
        if(thirdPair.getFoodPreference() == FoodPreference.MEAT || thirdPair.getFoodPreference() == FoodPreference.NONE) {
            count++;
        }
        return count;
    }

    // Scoring methods...

    // Beispiel test aufbau
    //Participant par1 = new Participant("123", "peter", FoodPreference.VEGAN, 23, Gender.FEMALE, null);
    // 6 mal wiederholen
    //par 2
    //...
    //Pair pair1 = new Pair(true, par1, par1);
    /// für 3 Paare
    //Group group = new Group(Course.DESSERT, pair1, pair1, pair1);
    // auf der Gruppe die Kalkulation testen Assertations.assertEquals(0.0, group.getAgeDiff())
    // das gleich für alle anderen Kalkulation

    public double getGroupAgeDiff() { //test Testdaten von Beispiel oben anpassen
        int ageDiff = Math.abs(this.getCookingPair().getFirstParticipant().ageRange() - this.getCookingPair().getSecondParticipant().ageRange());
        ageDiff += Math.abs(this.getSecondPair().getFirstParticipant().ageRange() - this.getSecondPair().getSecondParticipant().ageRange());
        ageDiff += Math.abs(this.getThirdPair().getFirstParticipant().ageRange() - this.getThirdPair().getSecondParticipant().ageRange());
        return (double)ageDiff / 3.0;
    }

    public double getGroupGenderDiff() { //test
        return (this.getCookingPair().calculateGenderDiff() + this.getSecondPair().calculateGenderDiff() + this.getThirdPair().calculateGenderDiff()) / 3.0;
    }

    public double calculateWeightedScore(int foodWeight, int genderWeight, int ageWeight) {
        return (this.getCookingPair().calculateWeightedScore(foodWeight, genderWeight, ageWeight)
                + this.getSecondPair().calculateWeightedScore(foodWeight, genderWeight, ageWeight)
                + this.getThirdPair().calculateWeightedScore(foodWeight, genderWeight, ageWeight)) / 3.0;
    } //test

    public List<Pair> getAllPairs() {
        List<Pair> allPairs = new ArrayList<>();
        allPairs.add(this.getCookingPair());
        allPairs.add(this.getSecondPair());
        allPairs.add(this.getThirdPair());
        return allPairs;
    }

    public static List<Pair> getAllPairs(List<Group> groups) {
        List<Pair> allPairs = new ArrayList<>();
        for(Group group : groups) {
            allPairs.addAll(group.getAllPairs());
        }
        return allPairs;
    }
}

