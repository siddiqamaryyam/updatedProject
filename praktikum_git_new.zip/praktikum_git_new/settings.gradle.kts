rootProject.name = "spinfood"

